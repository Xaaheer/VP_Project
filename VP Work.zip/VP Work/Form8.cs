﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS7th_WindowsFormApplication_USWAT
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string server = "localhost";
            string database = "windowsformapp";
            string username = "root";
            string password = "";
            string constring = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + username + ";" + "PASSWORD=" + password + ";";


            MySqlConnection conn = new MySqlConnection(constring);
            
            conn.Open();   
            
            MessageBox.Show("Connection open successfully");
            
            MySqlCommand com1 = new MySqlCommand();

            com1.Connection = conn;

            //com1.CommandText = "INSERT INTO `tabl1`(`Firstname`, `Lastname`, `Address`) VALUES ('Alamzaib','Khan','USWATCS') ";
           com1.CommandText = "INSERT INTO `tabl1`(`Firstname`, `Lastname`, `Address`) VALUES ('"+textBox1.Text+"','"+textBox2.Text+"','"+textBox3.Text+"') ";
           com1.ExecuteNonQuery();
           conn.Close();
           
            MessageBox.Show("Record inserted successfully");
        }
    }
}
