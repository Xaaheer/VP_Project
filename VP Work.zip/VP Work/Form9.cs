﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CS7th_WindowsFormApplication_USWAT
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"D:\Test5.txt";
            FileStream file = new FileStream(path, FileMode.Create, FileAccess.Write);
            file.WriteByte(66);
            MessageBox.Show("File created successfully");
            file.Close();

        }
    }
}
