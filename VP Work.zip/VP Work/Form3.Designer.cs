﻿namespace CS7th_WindowsFormApplication_USWAT
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TreeNode treeNode1 = new TreeNode("Swat");
            TreeNode treeNode2 = new TreeNode("KPK", new TreeNode[] { treeNode1 });
            TreeNode treeNode3 = new TreeNode("Islamabad");
            TreeNode treeNode4 = new TreeNode("Punjab", new TreeNode[] { treeNode3 });
            TreeNode treeNode5 = new TreeNode("Pakistan", new TreeNode[] { treeNode2, treeNode4 });
            TreeNode treeNode6 = new TreeNode("Mumbai");
            TreeNode treeNode7 = new TreeNode("India", new TreeNode[] { treeNode6 });
            TreeNode treeNode8 = new TreeNode("Kabal");
            TreeNode treeNode9 = new TreeNode("Afghanistan", new TreeNode[] { treeNode8 });
            TreeNode treeNode10 = new TreeNode("Jabbar");
            TreeNode treeNode11 = new TreeNode("Neepal", new TreeNode[] { treeNode10 });
            treeView1 = new TreeView();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            listView1 = new ListView();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // treeView1
            // 
            treeView1.Location = new Point(1029, 71);
            treeView1.Name = "treeView1";
            treeNode1.Name = "Node3";
            treeNode1.Text = "Swat";
            treeNode2.Name = "Node1";
            treeNode2.Text = "KPK";
            treeNode3.Name = "Node4";
            treeNode3.Text = "Islamabad";
            treeNode4.Name = "Node2";
            treeNode4.Text = "Punjab";
            treeNode5.Name = "Node0";
            treeNode5.Text = "Pakistan";
            treeNode6.Name = "Node6";
            treeNode6.Text = "Mumbai";
            treeNode7.Name = "Node5";
            treeNode7.Text = "India";
            treeNode8.Name = "Node8";
            treeNode8.Text = "Kabal";
            treeNode9.Name = "Node7";
            treeNode9.Text = "Afghanistan";
            treeNode10.Name = "Node10";
            treeNode10.Text = "Jabbar";
            treeNode11.Name = "Node9";
            treeNode11.Text = "Neepal";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode5, treeNode7, treeNode9, treeNode11 });
            treeView1.Size = new Size(151, 197);
            treeView1.TabIndex = 2;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // button1
            // 
            button1.Location = new Point(374, 312);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 92);
            label1.Name = "label1";
            label1.Size = new Size(24, 20);
            label1.TabIndex = 5;
            label1.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 175);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 6;
            label2.Text = "First Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 258);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 7;
            label3.Text = "Last Name";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(159, 85);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(159, 168);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 9;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(159, 251);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 10;
            // 
            // button2
            // 
            button2.Location = new Point(489, 312);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 11;
            button2.Text = "New";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(609, 312);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 12;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(726, 312);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 13;
            button4.Text = "Remove";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(843, 312);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 14;
            button5.Text = "Remove All";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // listView1
            // 
            listView1.BackColor = SystemColors.ControlDarkDark;
            listView1.GridLines = true;
            listView1.Location = new Point(374, 81);
            listView1.Name = "listView1";
            listView1.Size = new Size(563, 197);
            listView1.TabIndex = 15;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged_1;
            listView1.Click += listView1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1063, 281);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 16;
            label4.Text = "TreeView";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(374, 58);
            label5.Name = "label5";
            label5.Size = new Size(63, 20);
            label5.TabIndex = 17;
            label5.Text = "ListView";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1235, 450);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(listView1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(treeView1);
            Name = "Form3";
            Text = "List and Tree Views";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TreeView treeView1;
        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private ListView listView1;
        private Label label4;
        private Label label5;
    }
}