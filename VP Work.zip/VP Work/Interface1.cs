﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS7th_WindowsFormApplication_USWAT
{
    internal interface Interface1
    {
    }
}
